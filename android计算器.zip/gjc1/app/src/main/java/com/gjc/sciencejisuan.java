package com.gjc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class sciencejisuan extends Activity{

	//str为显示到textview的字符串
	//et 是编辑框对象
	String str="";
	EditText et;
	//c对应加减乘除的选择
	int c=0,flag=0;
	//bgf为操作数
	double b=0,g=0,f=0;
	View vi;
	

	
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0, 1, 1, "退出");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(item.getItemId()==1){finish();}
		return super.onOptionsItemSelected(item);
	}

	

	//使用自带的calculater方法
	public double calculater(){
		switch(c){
		case 0:f=g;break;
		case 1:f=b+g;break;
		case 2:f=b-g;break;
		case 3:f=b*g;break;
		case 4:f=b/g;break;
		}
		
		b=f;
		c=0;
		
		return f;
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sciencejisuan);



        final Button number[]=new Button[10];
		final Button fuhao[]=new Button[20];
		final RadioButton fuxuan[]=new RadioButton[4];
		RadioGroup rg;
		
		rg=(RadioGroup)findViewById(R.id.radioGroup);
		
		fuxuan[0]=(RadioButton)findViewById(R.id.radioButton1);
		fuxuan[1]=(RadioButton)findViewById(R.id.radioButton2);
		fuxuan[2]=(RadioButton)findViewById(R.id.radioButton3);
		fuxuan[3]=(RadioButton)findViewById(R.id.radioButton4);
		
		fuxuan[2].setChecked(true);
				
		fuhao[0]=(Button)findViewById(R.id.button01);
		fuhao[1]=(Button)findViewById(R.id.button02);
		fuhao[2]=(Button)findViewById(R.id.button03);
		fuhao[3]=(Button)findViewById(R.id.button04);
		fuhao[4]=(Button)findViewById(R.id.button05);
		fuhao[5]=(Button)findViewById(R.id.button06);
		fuhao[6]=(Button)findViewById(R.id.buttonqie2);
		fuhao[7]=(Button)findViewById(R.id.buttonce);
		fuhao[8]=(Button)findViewById(R.id.sin);
		fuhao[9]=(Button)findViewById(R.id.cos);
		fuhao[10]=(Button)findViewById(R.id.tan);
		fuhao[11]=(Button)findViewById(R.id.log);
		fuhao[12]=(Button)findViewById(R.id.ln);
		fuhao[13]=(Button)findViewById(R.id.jiecheng);
		fuhao[14]=(Button)findViewById(R.id.PI);
		fuhao[15]=(Button)findViewById(R.id.E);
		fuhao[16]=(Button)findViewById(R.id.daoshu);
		fuhao[17]=(Button)findViewById(R.id.pow);


		number[0]=(Button)findViewById(R.id.button0);
		number[1]=(Button)findViewById(R.id.button1);
		number[2]=(Button)findViewById(R.id.button2);
		number[3]=(Button)findViewById(R.id.button3);
		number[4]=(Button)findViewById(R.id.button4);
		number[5]=(Button)findViewById(R.id.button5);
		number[6]=(Button)findViewById(R.id.button6);
		number[7]=(Button)findViewById(R.id.button7);
		number[8]=(Button)findViewById(R.id.button8);
		number[9]=(Button)findViewById(R.id.button9);
		
		
        et=(EditText) findViewById(R.id.textView1);
        
 
        et.setText(str);

      
       

        fuhao[6].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(sciencejisuan.this,ezjisuan.class);
				startActivity(intent);
				finish();
			}
		});

        fuhao[7].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				b=0;c=0;g=0;
				str="";
				et.setText(str);

			}
		});

        
        //sin
        fuhao[8].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				str=Math.sin(a)+"";
				et.setText(str);
			}}
		});
        //cos
        fuhao[9].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				str=Math.cos(a)+"";
				et.setText(str);
			}}
		}); 
        //tan
        fuhao[10].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				str=Math.tan(a)+"";
				et.setText(str);
			}}
		});
        //log
        fuhao[11].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				str=Math.log10(a)+"";
				et.setText(str);
			}}
		});
        //ln
        fuhao[12].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
					
				double a=Double.parseDouble(str);
				str=(Math.log(a)/Math.log(Math.E))+"";
				et.setText(str);
			}}
		});
        //锟阶筹拷
        fuhao[13].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				int a=Integer.parseInt(str);
				int sumjiecheng=a;
				 for(int i=1;i<a;i++)
				 {
				     sumjiecheng*=i;
				     
				 }

				str=sumjiecheng+"";
				et.setText(str);
				
			}}
		});
      //PI
        fuhao[14].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub

				str=Math.PI+"";
				et.setText(str);
			}
		});
      //E
        fuhao[15].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				str=Math.E+"";
				et.setText(str);
			}
		});
      //1/a
        fuhao[16].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				str=(1/a)+"";
				et.setText(str);
			}}
		});
      //x^y
        fuhao[17].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				double a=Double.parseDouble(str);
				et.setText(String.valueOf(Math.pow(a, b)));
			}}
		});
        
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				switch(checkedId)
				{
				case R.id.radioButton1:
					Toast.makeText(sciencejisuan.this, "转换为二进制", Toast.LENGTH_SHORT).show();
					break;
				case R.id.radioButton2:
					Toast.makeText(sciencejisuan.this, "转换为八进制", Toast.LENGTH_SHORT).show();
					break;
				case R.id.radioButton3:
					Toast.makeText(sciencejisuan.this, "转换为十进制", Toast.LENGTH_SHORT).show();
					break;
				case R.id.radioButton4:
					Toast.makeText(sciencejisuan.this, "转换为十六进制", Toast.LENGTH_SHORT).show();
					break;
				}

			}
		});
        //Binary
        fuxuan[0].setOnClickListener(new View.OnClickListener() {
			
			@SuppressLint("UseValueOf") public void onClick(View v) {
				// TODO Auto-generated method stub
				et.setText("");
				if(str!=""){

						int a= Integer.parseInt(str);
						String s = Integer.toBinaryString(a);

						et.setText(s);
						s=0+"";


					//直接转换其他进制 功能未完成 失败。
//					else{
//						if(fuxuan[1].isChecked()==true){
//						String a = (new Double(g)).toString();
//						int q = Integer.parseInt(a, 8);
//						String s = Integer.toBinaryString(q);
//						et.setText(s);
//						g=Double.parseDouble(s);
//						s=0+"";
//							System.out.println("");
//						}
//						if(fuxuan[2].isChecked()==true){
//							String a = (new Double(g)).toString();
//							int q = Integer.parseInt(a, 10);
//							String s = Integer.toBinaryString(q);
//							et.setText(s);
//							g=Double.parseDouble(s);
//							s=0+"";
//							}
//						if(fuxuan[3].isChecked()==true){
//							String a = (new Double(g)).toString();
//							int q = Integer.parseInt(a, 16);
//							String s = Integer.toBinaryString(q);
//							et.setText(s);
//							g=Double.parseDouble(s);
//							s=0+"";
//							}
//					}
					
			}}
		});
        
      //OCT
        fuxuan[1].setOnClickListener(new View.OnClickListener() {
			
			@SuppressLint("UseValueOf") public void onClick(View v) {
				// TODO Auto-generated method stub
				et.setText("");
				if(str!=""){

						int a= Integer.parseInt(str);
						String s = Integer.toOctalString(a);
						et.setText(s);

						s=0+"";

			}}
		});
        
        //十进制
        fuxuan[2].setOnClickListener(new View.OnClickListener() {
			
			@SuppressLint("UseValueOf") public void onClick(View v) {
				// TODO Auto-generated method stub
				et.setText("");
				if(str!=""){

					int a= Integer.parseInt(str);
					String s =a+"";
					et.setText(s);
					s=0+"";


			}}
		});
        
        //hex
        fuxuan[3].setOnClickListener(new View.OnClickListener() {

			@SuppressLint("UseValueOf") public void onClick(View v) {
				// TODO Auto-generated method stub
				et.setText("");
				if(str!=""){
					int a= Integer.parseInt(str);
					String s = Integer.toHexString(a);

					et.setText(s);
					s=0+"";


					//直接转换其他进制 功能未完成 失败。
//				else{
//					if(fuxuan[0].isChecked()==true){
//					String a = (new Double(g)).toString();
//					int q = Integer.parseInt(a, 2);
//					String s = Integer.toHexString(q);
//					et.setText(s);
//					g=Double.parseDouble(s);
//					s=0+"";
//					}
//					if(fuxuan[1].isChecked()==true){
//						String a = (new Double(g)).toString();
//						int q = Integer.parseInt(a, 8);
//						String s = Integer.toHexString(q);
//						et.setText(s);
//						g=Double.parseDouble(s);
//						s=0+"";
//						}
//					if(fuxuan[2].isChecked()==true){
//						String a = (new Double(g)).toString();
//						int q = Integer.parseInt(a, 10);
//						String s = Integer.toHexString(q);
//						et.setText(s);
//						g=Double.parseDouble(s);
//						s=0+"";
//						}
//				}
			}
		}
	});



        number[0].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=0;
					et.setText(str);
					flag=0;
					}
				 else{
					char ch1[];
					ch1=str.toCharArray();
					if(!(ch1.length==1&&ch1[0]=='0'))
					{str+=0;
					et.setText(str);}
					
				 }
				vi=v;
			}
		});
        
        
        number[1].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=1;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=1;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[2].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=2;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=2;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[3].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=3;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=3;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[4].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=4;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=4;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[5].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=5;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=5;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[6].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=6;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=6;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[7].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=7;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=7;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[8].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=8;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=8;
					et.setText(str);
				 }
				vi=v;
			}
		});

        number[9].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(flag==1){
					str="";
					str+=9;
					et.setText(str);
					flag=0;
					}
				 else{
					str+=9;
					et.setText(str);
				 }
				vi=v;
			}
		});


    	//设定符号键
      //加
        fuhao[0].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				if(vi==fuhao[0]||vi==fuhao[1]||vi==fuhao[2]||vi==fuhao[3]){
					c=1;
				}
				
				else{
					g=Double.parseDouble(str);
					calculater();
					str=""+f;
					et.setText(str);
					c=1;
					flag=1;
					vi=v;
				}}
			}
		});

      //减
        fuhao[1].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				if(vi==fuhao[0]||vi==fuhao[1]||vi==fuhao[2]||vi==fuhao[3]){
					c=2;
				}
				
				else{
					g=Double.parseDouble(str);
					calculater();
					str=""+f;
					et.setText(str);
					c=2;
					flag=1;
					vi=v;
				}}
			}
		});

      //乘
        fuhao[2].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				if(vi==fuhao[0]||vi==fuhao[1]||vi==fuhao[2]||vi==fuhao[3]){
					c=3;
				}
				
				else{
					g=Double.parseDouble(str);
					calculater();
					str=""+f;
					et.setText(str);
					c=3;
					flag=1;
					vi=v;
				}}
			}
		});

      //除
        fuhao[3].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""){
				if(vi==fuhao[0]||vi==fuhao[1]||vi==fuhao[2]||vi==fuhao[3]){
					c=4;
				}
				
				else{
					g=Double.parseDouble(str);
					calculater();
					str=""+f;
					et.setText(str);
					c=4;
					flag=1;
					vi=v;
				}}
			}
		});


      //等号
        fuhao[4].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str!=""&&vi!=fuhao[0]&&vi!=fuhao[1]&&vi!=fuhao[2]&&vi!=fuhao[3]){
					g=Double.parseDouble(str);
					calculater();
					str=""+f;
					et.setText(str);
					flag=1;
					vi=v;

				}
			}
		});


		//.
        fuhao[5].setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(str==""){
					str+=".";
					et.setText(str);
				}
				else{
					char ch1[];int x=0;
					ch1=str.toCharArray();
					for(int i=0;i<ch1.length;i++)
						if(ch1[i]=='.')
							x++;
					if(x==0){
						str+=".";
						et.setText(str);
					}
				}

			}
		});
    }
    
  
		
}