package com.zcib.Servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zcib.Domain.User;
import com.zcib.Service.UserException;
import com.zcib.Service.UserService;


public class UserServlet extends HttpServlet {
	UserService userservice = new UserService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String action = request.getParameter("action");
		if("login".equals(action)){
			login(request,response);
		}else if("regist".equals(action)){
			regist(request,response);
		}else if("logout".equals(action)){
			logout(request,response);
		}else if("updatead".equals(action)){
			updatead(request,response);
		}else if("selectByName".equals(action)){
			selectByName(request,response);
		}
	}
	
	private void selectByName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username=request.getParameter("name");
		Map<String,String> map = new HashMap<String,String>();
		//验证数据的合法性
		if(username==null||username.trim().isEmpty()){
			map.put("iderror", "id不能为空");
		}
		if(map.size()>0){
			//有错误
			request.setAttribute("error",map);
			request.getRequestDispatcher("teacherlist.jsp").forward(request, response);
			return;
		}
		//封装用户信息
		User user=new User();
		user.setUsername(username);
	
		//调用service方法进行注册
		UserService userservice=new UserService();
		//返回添加信息
        request.setAttribute("list", userservice.selectByName(username));
		request.getRequestDispatcher("personal.jsp").forward(request, response);
	}
	private void updatead(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//获取表单数据
		String id=request.getParameter("id");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String birthday=request.getParameter("birthday");
		String email=request.getParameter("email");
		Map<String,String> map = new HashMap<String,String>();
		//验证表单的合法性
//		if(teaCode == null || teaCode.trim().isEmpty()){
//			map.put("tcerror", "职工号不能为空");
//		}
//		if(teaRealName == null || teaRealName.trim().isEmpty()){
//			map.put("tnerror", "姓名不能为空");
//		}
//		if(teaPwd == null || teaPwd.trim().isEmpty()){
//			map.put("tperror", "密码不能为空");
//		}
//		if(teaSex == null || teaSex.trim().isEmpty()){
//			map.put("tserror", "性别不能为空");
//		}
//		if(status == null || status.trim().isEmpty()){
//			map.put("sterror", "状态不能为空");
//		}
//		if(map.size()>0){
//			//有错误
//			request.setAttribute("error", map);
//			request.getRequestDispatcher("manage/updatetea.jsp").forward(request, response);
//			return;
//		}
		//封装用户信息
		User user=new User();
		user.setId(Integer.parseInt(id));
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setBirthday(birthday);
	
	    //调用service方法进行注册
		UserService userservice=new UserService();
		userservice.updatead(username,password,birthday,email,id);
		//返回添加信息
		
		request.setAttribute("msg", "更改成功");
		request.getRequestDispatcher("msg.jsp").forward(request, response);

	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		/*
		 * 1.使session失效 
		 * 2.跳转到login.jsp页面
		 */
		request.getSession().invalidate();
		 request.getRequestDispatcher("/login.jsp").forward(request,response);
	}

	//注册
	public void regist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 1.获取表单数据
		 * 2.验证表单数据的正确性
		 * 3.调用service的regist方法，进行注册
		 * 4.注册成功，返回User对象
		 */
		//获取表单数据
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		
		//验证表单数据的正确性
		Map<String, String> map = new HashMap<String, String>();

		// 2.验证表单数据的合法性
		if (username == null || username.trim().isEmpty()) {
			map.put("coerror", "用户名不能为空");
		}
		if (password == null || password.trim().isEmpty()) {
			map.put("pwerror", "密码不能为空");
		}
		if (email == null || email.trim().isEmpty()) {
			map.put("emerror", "邮箱不能为空");
		}
		
		//调用service的regist方法，进行注册
		UserService userService = new UserService();
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		try {
			userService.regist(user);
			request.setAttribute("msg", "用户注册成功！");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		} catch (UserException e) {
			request.setAttribute("error",e.getMessage());
			request.getRequestDispatcher("regist.jsp").forward(request, response);
		}
	}
	
	//登录
	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 1. 取出表单中的用户名和密码
		 * 2. 检查表单数据的正确性（非空，格式验证等）
		 *    检查验证码是否正确
		 * 3. 调用service层，来验证用户名和密码是否正确
		 *   4.正确，则保存用户信息到session中，跳转到主页面index.jsp
		 *   5.不正确，则保存错误信息到request中，重定向到错误显示页面。
		 */
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//1. 取出表单中的用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String verifyCode = request.getParameter("verifyCode");
		
		// 2. 验证表单数据的正确性（非空，格式验证等），不正确返回到login.jsp页面中
	
		if(username == null || username.trim().isEmpty()){
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(password == null || password.trim().isEmpty()){
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		if(verifyCode == null || verifyCode.trim().isEmpty()){
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}else if(!verifyCode.equalsIgnoreCase(request.getSession().getAttribute("verifyCode").toString())){
			//验证码输入不正确，则返回错误信息，重新输入
			request.setAttribute("verifyCodeError", "验证码不正确，请重新输入");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		// 3. 调用service层，来验证用户名和密码是否正确
		UserService userService = new UserService();
		try{
			boolean user = userService.validate(username, password);
			//4.正确，则保存用户信息到session中，跳转到主页面index.jsp
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		}catch(UserException e){
			// 5.不正确，则保存错误信息到request中，重定向到错误显示页面。
				request.setAttribute("msg", e.getMessage());
				request.getRequestDispatcher("/msg.jsp").forward(request,response);
		}
	}
}
