package com.zcib.Servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zcib.Domain.New;
import com.zcib.Domain.Page;
import com.zcib.Service.NewsService;

public class NewsServlet extends HttpServlet {
	private NewsService newsService = new NewsService();
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String action = request.getParameter("action");
		if("addNew".equals(action)){
			addNew(request,response);
		}else if("findAll".equals(action)){
			findAll(request,response);
		}else if ("findByKey".equals(action)) {
			findByKey(request, response);
		} else if ("UpdateOne".equals(action)) {
			UpdateOne(request, response);
		} else if ("update".equals(action)) {
			update(request, response);
		}  else if ("deleteById".equals(action)) {
			deleteById(request, response);
		}  else if ("deleteMore".equals(action)) {
			deleteMore(request, response);
		}else if ("addNews".equals(action)) {
			addNews(request, response);
		} 
	}

	private void addNews(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取表单信息，验证 2.封装到Stu对象中 3.调用Service的addStu方法，添加一条新闻 4.根据返回信息，
		 * 5.跳转到addStus.jsp页面，显示提示信息
		 */
		New news = new New();
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String content = request.getParameter("content");
		String publishedDate = request.getParameter("publishedDate");
		news.setTitle(title);
		news.setAuthor(author);
		news.setContent(content);
		try {
			news.setPublishedDate(new SimpleDateFormat("yyyy-MM-dd").parse(publishedDate));
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage(),e);
		}
		newsService.addNews(news);
		request.setAttribute("msg", "添加成功!");
		request.getRequestDispatcher("/addnew.jsp").forward(request, response);
	}

	private void UpdateOne(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 根据stuIdid更改一条记录 1.获取id值 2.调用service的updateById删除该条记录
		 * 3.调换到学生列表中，显示更改过后的学生列表
		 */
		String Id = request.getParameter("newsId");
		request.setAttribute("list",newsService.updateById(Id));
		request.getRequestDispatcher("updatenew.jsp").forward(request, response);
	}
	
	private void deleteById(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 根据stuIdid删除一条新闻 1.获取id值 2.调用service的deleteByID删除该条记录
		 * 3.调换到学生列表中，显示删除过后的学生列表
		 */
		String newsId = request.getParameter("newsId");
		newsService.deleteById(newsId);
		findAll(request, response);
	}
	
	private void deleteMore(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取要删除的stuId数组 2.调用service层的方法删除这些记录 3.调用findAll方法
		 */
		// 1.获取要删除的stuIdid数组
		String[] newsIds = request.getParameterValues("sel");
		// 2.调用service层的方法删除这些记录
		newsService.deleteMore(newsIds);
		// 3.调用findAll方法
		findAll(request, response);
	}
	
	private void update(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		/*
		 * 1.获取表单数据 2.验证表单合法性 3.调用service的update方法进行更改
		 */
		// 1.获取表单数据
		String id = request.getParameter("id");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String content = request.getParameter("content");
		String publishedDate = request.getParameter("publishedDate");
		// 2.验证表单合法性
		Map<String, String> map = new HashMap<String, String>();

		if (id == null || id.trim().isEmpty()) {
			map.put("unerror", "编号不能为空!");
		} else if (title == null || title.trim().isEmpty()) {
			map.put("pwerror", "密码不能为空!");
		} else if (author == null || author.trim().isEmpty()) {
			map.put("reerror", "作者不能为空!");
		} else if (content == null || content.trim().isEmpty()) {
			map.put("sexerror", "内容不能为空!");
		} else if (publishedDate == null || publishedDate.trim().isEmpty()) {
			map.put("staerror", "发布时间不能为空!");
		}
		if (map.size() > 0) {
			// 有错误
			request.setAttribute("error", map);
			request.getRequestDispatcher("stuupdate.jsp").forward(request,
					response);
			return;
		}
		New news = new New();
		news.setId(Integer.parseInt(id));
		news.setTitle(title);
		news.setAuthor(author);
		news.setContent(content);
		try {
			news.setPublishedDate(new SimpleDateFormat("yyyy-MM-dd").parse(publishedDate));
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage(),e);
		}
		// 3.调用service中的update方法进行修改信息
		newsService.update(news);
		// 4.返回列表
		findAll(request, response);
	}
	
	private void findAll(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 0.获取当前页 1.有当前页，当前页的值位currentPage，没有当前页，默认值为1
		 * 2.调用Service的findAll方法根据当前页获取Page对象 3.保存到request域中 4.返回到list页面
		 */

		// //1.调用Service的findAll方法获取所有学生列表//2.保存到request域中
		// request.setAttribute("list", stuService.findStusList());
		// //3.返回到stulist.jsp页面
		// request.getRequestDispatcher("/stulist.jsp").forward(request,response);

		// 0.获取当前页
		String currentPage = request.getParameter("currentPage");
		String username = request.getParameter("username");
		// 1.有当前页，当前页的值位currentPage，没有当前页，默认值为1
		int current;
		try {
			current = Integer.parseInt(currentPage);
		} catch (Exception e) {
			current = 1;
		}

		// 2.调用Service的findStusList方法根据当前页获取Page对象
		Page page = newsService.findNewssList(current);
		// 3.保存到request域中
		request.setAttribute("page", page);
		request.setAttribute("url", request.getContextPath()+"/newsServlet?action=findAll");
		// 4.返回到stulist.jsp页面
			request.getRequestDispatcher("/newslist.jsp").forward(request, response);

	}
	
	private void findByKey(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取key值 2.判断key的合法性 3.不合法,查询所有的记录 4.合法,查找关键字的所有记录 5.存入request域中
		 * 6.转到tealist.jsp页面
		 */
		// 0.获取当前页//查询之后也可以分页
		String currentPage = request.getParameter("currentPage");
		// 1.有当前页，当前页的值位currentPage，没有当前页，默认值为1
		int current;
		try {
			current = Integer.parseInt(currentPage);
		} catch (Exception e) {
			current = 1;
		}
		// 1.获取key值
		String key = request.getParameter("key");
		// 2.判断key的合法性
		if (key == null || key.trim().isEmpty()) {
			findAll(request, response);
		} else {
			// 4.合法,查找关键字的所有记录//5.存入request域中
			request.setAttribute("page", newsService.findByKey(key, current));
			System.out.println(newsService.findByKey(key, current));
			request.setAttribute("key", key);
			request.setAttribute("url", request.getContextPath()+"/userServlet?action=findByKey");
			// 6.转到stulist.jsp页面
			request.getRequestDispatcher("/newslist.jsp").forward(request,response);
		}
	}
	
	
	
	public void addNew(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 添加一条新闻
		 * 1.获取表单信息
		 * 2.验证表单数据的正确性
		 * 3.把标表单数据封装到New对象中
		 * 4.调用Service的addNew方法，添加一条新闻
		 * 5.将发布成功信息转发到addNew.jsp页面
		 */
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String content = request.getParameter("content");
		String publishedDate = request.getParameter("publishedDate");
		//验证表单数据的正确性
		//把表单数据封装到New对象中
		New annew = new New();
		annew.setTitle(title);
		annew.setAuthor(author);
		annew.setContent(content);
		try {
			annew.setPublishedDate(new SimpleDateFormat("yyyy-MM-dd").parse(publishedDate));
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage(),e);
		}
		//调用Service的addnew方法,添加一条新闻
		newsService.addNew(annew);
		request.setAttribute("msg","发布成功！");
		request.getRequestDispatcher("/addnew.jsp").forward(request, response);
	}
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}
}
