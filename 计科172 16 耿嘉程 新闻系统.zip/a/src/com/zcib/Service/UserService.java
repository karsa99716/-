package com.zcib.Service;

import java.util.List;
import java.util.Map;

import com.zcib.Dao.UserDao;
import com.zcib.Domain.Page;
import com.zcib.Domain.User;


public class UserService {
	private UserDao userDao = new UserDao();
	/*
	 * 通过用户名和密码查询user对象，返回User
	 */
	public boolean validate(String username,String password) throws UserException {
		
		/*
		 * 1.调用Dao层中的findByUsername方法
		 *   返回一个User对象
		 * 2. User对象是否为空，用户名不存在，返回false
		 * 3. User对象不为空，判断密码是否正确
		 *    3.1 比较密码是否正确，正确，返回true
		 *    3.2 密码不正确，返回false
		 */
		
		//1.调用Dao层中的findByUsername方法
		User user = userDao.find(username);
		boolean flag = false;
		if(user!=null && password.equals(user.getPassword())){
			flag = true;
		}
		 
		return flag;
	}
	/*
	 * 注册新用户
	 * 调用UserDao中的insert方法，将数据存入数据库中
	 * 注册成功，返回User对象
	 * 不成功，返回空
	 */
	public void regist(User user) throws UserException{
		User cUser = userDao.find(user.getUsername());
		if(cUser != null)
			throw new UserException("用户名已占用！");
		//还可以查询email是否已使用
		userDao.insert(user);
	}
	public User findadminsList(String username) {
		return userDao.find(username);
	}
	public void updatead(String username, String password, String birthday, String email, String id) {

		userDao.updatead(username, password, birthday,email,id);
	}
	public User selectByName(String username) {
        
		return userDao.selectByName(username);
	}
	
	
}
