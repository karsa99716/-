package com.zcib.Service;

import java.util.List;
import java.util.Map;

import com.zcib.Dao.NewsDao;
import com.zcib.Domain.New;
import com.zcib.Domain.Page;


public class NewsService {
	private NewsDao newsDao = new NewsDao();
	
	/*
	 * 获取新闻列表
	 */
	public List<Map<String,Object>> findNewsList(){
		return newsDao.findAll();
	}
	/*
	 * 添加一条新闻
	 */
	public void addNew(New annew){
		newsDao.insert(annew);
	}
	public New updateById(String Id){
		return newsDao.updateById(Id);
	}
	
	public Page findNewssList(int current) {
		//读取当前页学生列表，并封装到Page
			/*
			 * 0.查询数据库获取总条数，调用Dao获取
			 * 1.构造Page对象
			 * 2.调用Dao层获取学生列表
			 * 3.将获取的当前页的学会说呢过列表设置给Page的list属性
			 */
			//0.查询数据库获取总条数，调用Dao获取
			int total = newsDao.findTotal();
			//1.构造Page对象
			Page page = new Page(current,total);
			//2.调用Dao层获取学生列表
			List<Map<String,Object>> list = newsDao.findAll(page.getStartIndex(),page.getPageSize());
			page.setList(list);
			return page;
	}
	public Object findByKey(String key, int current) {
		//查询key的当前页的学生列表,也要封装到Page中
			/*
			 * 0.查询数据库所有包括关键字总条数，调用Dao获取
			 * 1.构造Page对象
			 * 2.调用Dao层获取包括了关键字学生列表
			 * 3.将获取的当前页的学会说呢过列表设置给Page的list属性
			 */
			//0.查询数据库获取总条数，调用Dao获取
			int total = newsDao.findTotal(key);
			// 1.构造Page对象
			Page page = new Page(current, total);
			// 2.调用Dao层获取学生列表
			List<Map<String, Object>> list = newsDao.findAll(page.getStartIndex(),page.getPageSize(),key);
			page.setList(list);
			return page;
		}

	
	public void update(New news) {
		newsDao.update(news);
		
	}
	public void deleteById(String newsId) {
			newsDao.deleteById(newsId);
	}
	public void deleteMore(String[] newsIds) {
		newsDao.deleteById(newsIds);
		
	}
	public void addNews(New news) {
		newsDao.insert(news);
		
	}

}
