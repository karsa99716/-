package com.zcib.Domain;

import java.util.List;
import java.util.Map;

public class Page {
	private int pageSize = 4;//一页要显示的条数
	private int currentPage;//当前页，由页数传递过来的
	private int totalSize;//总条数，查询数据库得来的
	//private int totalPage;//总页数，需要计算出来
	//private int startIndex;//读取的起始记录的索引，可以计算得出
	private List<Map<String,Object>> list;//当前页中所包含的记录数目
	private int num = 6;//页面上显示的页码个数
	//private int start;//页面显示页码的起始值
	//private int end;//页面显示页码的终止值
	public Page(int currentPage,int totalSize){
		this.totalSize = totalSize;
		//this.currentPage = currentPage;
		setCurrentPage(currentPage);
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		//小于1
		if(currentPage < 1){
			currentPage = 1;
		}
		//大于总页数
		int totalPage = getTotalPage();
		if(currentPage > totalPage){
			currentPage = totalPage;
		}
			this.currentPage = currentPage;
	}
	public int getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}
	//读取起始记录的索引，可以计算出来
	//第一页,0
	//第二页,10
	//第三页,20
	//第i页,(i-1)*10
	public int getStartIndex() {
		int index = (currentPage-1)*pageSize;
		System.out.println(currentPage+":"+index);
//		if(index < 0){
//			index = 0;
//		}
		return index;
	} 
	public List<Map<String, Object>> getList() {
		return list;
	}
	public void setList(List<Map<String, Object>> list) {
		this.list = list;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	//页面显示页码的起始值
	//1,2,3,4,5,6  3
	//2,3,4,5,6,7  4
	//3,4,5,6,7,8  5
	//start=10,11,12,13,14,15  currentPage=12  num
	public int getStart() {
		int start = currentPage - num/2;
		if(start < 1){
			start = 1;
		}
		return start;
	}
	//页面显示页码的终止值
	public int getEnd() {
		int end = getStart() + num -1;
		int totalPage = getTotalPage();
		if(end > totalPage){
			end = totalPage;
		}
		return end;
	}
	//有多少页，需要计算出来
	//100条/10=10
	//101条/10=11
	public int getTotalPage() {
		return (totalSize%pageSize == 0)?(totalSize/pageSize):(totalSize/pageSize+1);
	}
	public String toString() {
		return "Page [pageSize=" + pageSize + ", currentPage=" + currentPage
				+ ", totalSize=" + totalSize + ", list=" + list + ", num="
				+ num + "]";
	}
}
