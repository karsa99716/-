package com.zcib.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.zcib.Domain.User;
import com.zcib.Utils.JDBCUtils;
public class UserDao {
	
	/*根据用户名查找数据库
	 * 查找成功，则返回User对象
	 * 查找失败，抛出异常
	 */
	public User find(String username){
		/*
		 * 1.根据用户名查找用户
		 * 2.如果有该用户，返回该用户对象
		 * 3.如果没有该用户，则抛出异常。
		 */
		User user = null;
		String sql = "select * from tb_user where username=?";
		List<Map<String,Object>> list = JDBCUtils.select(sql, username);
		if(list.size()>0){
			//读取到记录
			Map map = list.get(0);
			//转换成admin对象
			user = new User();
			user.setId(Integer.parseInt(map.get("id").toString()));
			user.setUsername(map.get("username").toString());
			user.setPassword(map.get("password").toString());
			user.setEmail(map.get("email").toString());
		}
		return user;
	}
	
	
	/*
	 * 将User中的数据写入数据库，注册成功
	 */
	public void insert(User user){
		String sql = "insert into tb_user values(null,?,?,?)";
		Object params[]={
				user.getUsername(),
				user.getPassword(),
				user.getEmail()
		};
		JDBCUtils.insert(sql, params);
}


	public void updatead(String username, String password, String birthday, String email, String id) {

		String sql = "update tb_user set username=?, password=? ,birthday=?,email=? where id=?";
		//String sql="update t_stu set stuCode='"+stuCode+"',stuRealName='"+stuRealName+"',StuPwd='"+StuPwd+"',stuSex='"+stuSex+"',status='"+status+"' where stuId='"+stuId+"'";
		JDBCUtils.update(sql,username, password,birthday,email, id);

		
	}


	public User selectByName(String username) {
		User user = null;
		String sql="select * from tb_user where username=?";
		List<Map<String,Object>> list = JDBCUtils.select(sql, username);
		if(list.size()>0){
			//读取到记录
			Map map = list.get(0);
			user = new User();
			user.setId(Integer.parseInt(map.get("id").toString()));
			user.setUsername(map.get("username").toString());
			user.setBirthday(map.get("birthday").toString());
			user.setEmail(map.get("email").toString());
			user.setPassword(map.get("password").toString());
		}
		return user;
	}
	

	}