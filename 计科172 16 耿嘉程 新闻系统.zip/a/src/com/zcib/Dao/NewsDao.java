package com.zcib.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zcib.Domain.New;
import com.zcib.Utils.JDBCUtils;


public class NewsDao {
	// 获取新闻列表
	public List<Map<String, Object>> findAll() {
		String sql = "select * from tb_news";
		return JDBCUtils.select(sql);
	}

	public int findTotal() {
		//获取学生表条数
			String sql = "select count(*) from tb_news";
			Number n = (Number)JDBCUtils.selectScalar(sql);
			
			return n.intValue();
		}

	
	public int findTotal(String key) {
		String sql = "select count(*) from tb_news where title like '%" + key + "%' ";
		Number n = (Number)JDBCUtils.selectScalar(sql);
		return n.intValue();
	}

	public New updateById(String Id){
		New n=null;
		String sql = "select * from tb_news where id=?";
		List<Map<String, Object>> list = JDBCUtils.select(sql, Id);
		if(list.size()>0){
			//读取到记录
			Map map = list.get(0);
			n = new New();
			n.setId(Integer.parseInt(map.get("id").toString()));
			n.setTitle(map.get("title").toString());
			n.setAuthor(map.get("author").toString());
			n.setContent(map.get("content").toString());
			n.setPublishedDate((Date) map.get("publishedDate"));	
		}
		return n;
	}
	
	//获取了包括关键字key的当前页所有记录
		public List<Map<String, Object>> findAll(int startIndex, int pageSize,
				String key) {
			String sql = "select * from tb_news  where title LIKE '%" + key + "%' limit ?,?";
			Object params[]={
				startIndex,pageSize	
			};
			return JDBCUtils.select(sql, params);
		}

	public List<Map<String, Object>> findAll(int startIndex, int pageSize) {
		//读取当前页的学生列表
			String sql = "select * from tb_news limit ?,?";
			Object params[]={
				startIndex,pageSize	
			};
			return JDBCUtils.select(sql, params);
	}
	public void insert(New annew) {
		String sql = "insert into tb_news values(null,?,?,?,?)";
		Object params[]={
				annew.getTitle(),
				annew.getAuthor(),
			annew.getContent(),
			annew.getPublishedDate()
		};
		JDBCUtils.insert(sql, params);
	}


	public void update(New news) {
			String sql = "update tb_news set title=?,author=?,content=?,publishedDate=? where id=?";
			Object params[]={
					news.getTitle(),
					news.getAuthor(),
					news.getContent(),
					news.getPublishedDate(),
					news.getId(),
			};
			JDBCUtils.update(sql, params);
		}

	public void deleteById(String newsId) {
			String sql = "delete from tb_news where id=?";
			JDBCUtils.update(sql,newsId);
		}

	public void deleteById(String[] newsIds) {
				StringBuilder sql = new StringBuilder("delete from tb_news where id in (");
				for(int i=0;i<newsIds.length;i++){
					if(i == newsIds.length - 1){
						//如果不是最后一个，拼上?,
						sql.append("?)");
					}else{
						//如果是最后一个，?)
						sql.append("?,");
					}
				}
				System.out.println(sql.toString());
				JDBCUtils.update(sql.toString(),newsIds);
	}
}
